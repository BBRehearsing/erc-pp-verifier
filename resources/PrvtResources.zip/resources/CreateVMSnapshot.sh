#!/bin/bash
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Examples:
#     > $0 VIRT_IP=10.116.5.50 SNAPSHOT_NAME=new_snapshot \
#          DOMAIN_NAMES=CMS31-98-DB,CMS31-97-App
#     > $0 -r VIRT_IP=10.116.5.50 SNAPSHOT_NAME=old_snapshot \
#          DOMAIN_NAMES=CMS31-98-DB,CMS31-97-App
#
# Prerequisites:
#     > NONE
#
# To Be Improved:
#     > DONE
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

function resolveCommandLineArguments {
while [ $# -ge 1 ]; do
  case "$1" in
  VIRT_IP=*)
      VIRT_IP=${1#VIRT_IP=}
      echo "VIRT_IP=${VIRT_IP}"
      ;;
  SNAPSHOT_NAME=*)
      SNAPSHOT_NAME=${1#SNAPSHOT_NAME=}
      echo "SNAPSHOT_NAME=${SNAPSHOT_NAME}"
      ;;
  DOMAIN_NAMES=*)
      DOMAIN_NAMES=${1#DOMAIN_NAMES=}
      echo "DOMAIN_NAMES=${DOMAIN_NAMES}"
      ;;
  -r|-R)
      REPLACE=true
      echo "REPLACE=true"
      ;;
  *)
      ;;
  esac

  shift
done
}

function printHelpInfo {
cat <<HELP
Usage: $0 [-r|-R] VIRT_IP=<VIRT_IP> \\
          SNAPSHOT_NAME=<SNAPSHOT_NAME> \\
          DOMAIN_NAMES=<DOMAIN_NAMES>
HELP
}

resolveCommandLineArguments "$@"
[ -z "$VIRT_IP" -o -z "$SNAPSHOT_NAME" -o -z "$DOMAIN_NAMES" ] && {
  echo "Required parameters are missed."
  printHelpInfo
  exit 1
}

# Resolve multiple domain names
declare -a ARR_DOMAINS=()
for dmn in $(echo $DOMAIN_NAMES | tr ',' ' ')
do
  ARR_DOMAINS+=($dmn)
done

## Main job
set -x
for vm in "${ARR_DOMAINS[@]}"
do
  if ssh $VIRT_IP "virsh snapshot-list $vm | grep '$SNAPSHOT_NAME'"; then
    # the snapshot already exists
    if [ "true" = "${REPLACE}" ]; then
      ssh $VIRT_IP "virsh snapshot-delete $vm $SNAPSHOT_NAME"
    else
      echo "The snapshot of $SNAPSHOT_NAME for $vm already exists. Use -r if you want to replace it."
      set +x
      exit 1
    fi
  fi
  
  ssh $VIRT_IP "virsh destroy $vm"
  ssh $VIRT_IP "virsh snapshot-create-as $vm $SNAPSHOT_NAME"
  ssh $VIRT_IP "virsh start $vm"
  sleep 10;
done
set +x

